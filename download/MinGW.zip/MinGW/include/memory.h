/*
 * This file is part of the Mingw32 package.
 *
 * memory.h maps to the standard string.h header.
 */

#include	<string.h>
